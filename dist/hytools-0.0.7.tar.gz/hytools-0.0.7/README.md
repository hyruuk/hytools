Various tools for neurophysiological (MEG) analysis, mostly based on the CTF-275
setup from the MEG center at University of Montréal.

Also includes functions for behavioural analysis.
